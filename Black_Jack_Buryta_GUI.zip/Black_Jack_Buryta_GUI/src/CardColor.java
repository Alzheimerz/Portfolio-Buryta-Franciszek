public enum CardColor {
    SPADES,
    HEARTS,
    DIAMONDS,
    CLUBS
}
