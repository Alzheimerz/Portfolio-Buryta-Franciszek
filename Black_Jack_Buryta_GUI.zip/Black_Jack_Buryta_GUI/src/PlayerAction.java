public enum PlayerAction {
    HIT,
    STAND
}