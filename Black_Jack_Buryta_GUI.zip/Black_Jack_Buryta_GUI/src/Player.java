public class Player extends AbstractPlayer {

    private double budget;

    public Player(double budget){
        this.budget=budget;
    }

    public double getBudget(){
        return budget;
    }

    public boolean placeBet(double amount){

        if(amount>budget || amount<=0)
            return false;

        budget-=amount;
        return true;
    }

    public void winBet(double bet){
        budget+=bet*2;
    }

    public void pushBet(double bet){
        budget+=bet;
    }

    @Override
    public void performAction(Deck deck){}
}
