public abstract class AbstractPlayer {

    protected Hand gameHand=new Hand();

    public void getCard(BJCard card){
        gameHand.addCard(card);
    }

    public Hand getGameHand(){
        return gameHand;
    }

    public abstract void performAction(Deck deck);
}
