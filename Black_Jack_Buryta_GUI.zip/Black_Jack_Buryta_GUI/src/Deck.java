import java.util.Collections;
import java.util.ArrayList;

public class Deck {

    private ArrayList<BJCard> cards = new ArrayList<>();

    public Deck() {

        for(int d = 0; d < 5; d++) { // 5 Decks

            for(CardColor color : CardColor.values()) {

                for(CardValue value : CardValue.values()) {

                    cards.add(new BJCard(color, value));
                }
            }
        }

        Collections.shuffle(cards);
    }

    public BJCard drawCard() {

        if(cards.isEmpty()) return null;

        return cards.remove(0);
    }
}
