import javax.swing.*;

public class Main {

    private static Player player=new Player(1000);
    private static Dealer dealer=Dealer.getInstance();
    private static Deck deck;

    private static BlackjackGUI gui;

    private static double bet;

    public static void main(String[] args){

        gui=new BlackjackGUI();

        gui.getStartButton().addActionListener(e->startRound());
        gui.getHitButton().addActionListener(e->hit());
        gui.getStandButton().addActionListener(e->stand());
    }

    private static void startRound(){

        try{
            bet=Double.parseDouble(gui.getBet());
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(gui,"Invalid Bet");
            return;
        }

        if(!player.placeBet(bet)){
            JOptionPane.showMessageDialog(gui,"Not enough money");
            return;
        }

        gui.updateMoney(player.getBudget());

        deck=new Deck();

        player.getGameHand().clear();
        dealer.getGameHand().clear();

        gui.clearCards();

        BJCard p1=dealer.fetchCard(deck);
        player.getCard(p1);
        gui.addPlayerCard(p1.getImagePath());

        BJCard d1=dealer.fetchCard(deck);
        dealer.getCard(d1);
        gui.addDealerCard("cards/Back.png");

        BJCard p2=dealer.fetchCard(deck);
        player.getCard(p2);
        gui.addPlayerCard(p2.getImagePath());

        BJCard d2=dealer.fetchCard(deck);
        dealer.getCard(d2);
        gui.addDealerCard(d2.getImagePath());
    }

    private static void hit(){

        BJCard card=dealer.fetchCard(deck);
        player.getCard(card);

        gui.addPlayerCard(card.getImagePath());

        if(player.getGameHand().getValue()>21)
            endRound();
    }

    private static void stand(){

        dealer.performAction(deck);

        gui.clearCards();

        for(BJCard c:player.getGameHand().getCards())
            gui.addPlayerCard(c.getImagePath());

        for(BJCard c:dealer.getGameHand().getCards())
            gui.addDealerCard(c.getImagePath());

        endRound();
    }

    private static void endRound(){

        int playerValue=player.getGameHand().getValue();
        int dealerValue=dealer.getGameHand().getValue();

        if(playerValue>21){
            JOptionPane.showMessageDialog(gui,"Player Bust");
        }
        else if(dealerValue>21 || playerValue>dealerValue){
            player.winBet(bet);
            JOptionPane.showMessageDialog(gui,"Player Wins");
        }
        else if(dealerValue>playerValue){
            JOptionPane.showMessageDialog(gui,"Dealer Wins");
        }
        else{
            player.pushBet(bet);
            JOptionPane.showMessageDialog(gui,"Push");
        }

        gui.updateMoney(player.getBudget());
    }
}
