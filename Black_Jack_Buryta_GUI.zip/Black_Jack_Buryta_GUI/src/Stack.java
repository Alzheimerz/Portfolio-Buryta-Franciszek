import java.util.Collections;
import java.util.List;

public class Stack {

    private List<BJCard> cards;

    public Stack(List<BJCard> cards){
        this.cards=cards;
        Collections.shuffle(cards);
    }

    public BJCard draw(){
        return cards.remove(0);
    }
}
