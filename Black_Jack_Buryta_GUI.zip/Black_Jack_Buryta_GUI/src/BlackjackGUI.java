import javax.swing.*;
import java.awt.*;

public class BlackjackGUI extends JFrame {

    private JPanel dealerPanel=new JPanel();
    private JPanel playerPanel=new JPanel();

    private JLabel moneyLabel=new JLabel("Money: 1000");
    private JTextField betField=new JTextField(5);

    private JButton startButton=new JButton("Start");
    private JButton hitButton=new JButton("Hit");
    private JButton standButton=new JButton("Stand");

    public BlackjackGUI(){

        setTitle("Blackjack");
        setSize(1000,700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel background=new JLabel(ImageLoader.load("ui/background.png"));
        background.setLayout(new BorderLayout());
        setContentPane(background);

        dealerPanel.setOpaque(false);
        playerPanel.setOpaque(false);

        JPanel controls=new JPanel();
        controls.setOpaque(false);

        controls.add(moneyLabel);
        controls.add(new JLabel("Bet"));
        controls.add(betField);
        controls.add(startButton);
        controls.add(hitButton);
        controls.add(standButton);

        background.add(dealerPanel,BorderLayout.NORTH);
        background.add(playerPanel,BorderLayout.CENTER);
        background.add(controls,BorderLayout.SOUTH);

        setVisible(true);
    }

    public void clearCards(){
        dealerPanel.removeAll();
        playerPanel.removeAll();
        repaint();
    }

    public void addPlayerCard(String path){
        playerPanel.add(new JLabel(ImageLoader.load(path)));
        playerPanel.revalidate();
    }

    public void addDealerCard(String path){
        dealerPanel.add(new JLabel(ImageLoader.load(path)));
        dealerPanel.revalidate();
    }

    public void updateMoney(double money){
        moneyLabel.setText("Money: "+money);
    }

    public String getBet(){
        return betField.getText();
    }

    public JButton getStartButton(){ return startButton; }
    public JButton getHitButton(){ return hitButton; }
    public JButton getStandButton(){ return standButton; }

}
