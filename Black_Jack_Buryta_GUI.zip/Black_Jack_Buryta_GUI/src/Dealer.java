public class Dealer extends AbstractPlayer {

    private static Dealer instance;

    private Dealer(){}

    public static Dealer getInstance(){

        if(instance==null)
            instance=new Dealer();

        return instance;
    }

    public BJCard fetchCard(Deck deck){
        return deck.drawCard();
    }

    @Override
    public void performAction(Deck deck) {

        while (gameHand.getValue() < 17) {
            gameHand.addCard(deck.drawCard());
        }
    }

}
