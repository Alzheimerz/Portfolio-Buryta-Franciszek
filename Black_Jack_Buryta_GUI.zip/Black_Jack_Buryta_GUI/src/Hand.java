import java.util.ArrayList;
import java.util.List;

public class Hand {

    private List<BJCard> cards=new ArrayList<>();

    public void addCard(BJCard card){
        cards.add(card);
    }

    public void clear(){
        cards.clear();
    }

    public List<BJCard> getCards(){
        return cards;
    }

    public int getValue(){

        int sum=0;
        int aces=0;

        for(BJCard c:cards){

            sum+=c.getBJValue();

            if(c.getValue()==CardValue.ACE)
                aces++;
        }

        while(sum>21 && aces>0){
            sum-=10;
            aces--;
        }

        return sum;
    }
}
