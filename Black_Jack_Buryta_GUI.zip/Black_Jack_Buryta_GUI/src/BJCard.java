public class BJCard {

    private CardColor color;
    private CardValue value;

    public BJCard(CardColor color, CardValue value) {
        this.color = color;
        this.value = value;
    }

    public CardColor getColor() {
        return color;
    }

    public CardValue getValue() {
        return value;
    }

    public int getBJValue() {
        return value.getValue();
    }

    public String getImagePath(){

        String suit="";

        switch(color){
            case SPADES: suit="S"; break;
            case HEARTS: suit="H"; break;
            case DIAMONDS: suit="D"; break;
            case CLUBS: suit="C"; break;
        }

        return "cards/"+suit+value.getSymbol()+".png";
    }
}
