import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class HandTest {

    @Test
    public void testBlackjackValues() {

        // Testfall 1: 25
        Hand h1 = new Hand();
        h1.addCard(new BJCard(CardColor.HEARTS, CardValue.KING));
        h1.addCard(new BJCard(CardColor.DIAMONDS, CardValue.JACK));
        h1.addCard(new BJCard(CardColor.CLUBS, CardValue.FIVE));
        assertEquals(25, h1.getValue());

        // Testfall 2: 21
        Hand h2 = new Hand();
        h2.addCard(new BJCard(CardColor.HEARTS, CardValue.KING));
        h2.addCard(new BJCard(CardColor.DIAMONDS, CardValue.JACK));
        h2.addCard(new BJCard(CardColor.CLUBS, CardValue.ACE));
        assertEquals(21, h2.getValue());

        // Testfall 3: 21
        Hand h3 = new Hand();
        h3.addCard(new BJCard(CardColor.DIAMONDS, CardValue.JACK));
        h3.addCard(new BJCard(CardColor.CLUBS, CardValue.ACE));
        assertEquals(21, h3.getValue());

        // Testfall 4: 12
        Hand h4 = new Hand();
        h4.addCard(new BJCard(CardColor.HEARTS, CardValue.ACE));
        h4.addCard(new BJCard(CardColor.CLUBS, CardValue.ACE));
        assertEquals(12, h4.getValue());

        // Testfall 5: 20
        Hand h5 = new Hand();
        h5.addCard(new BJCard(CardColor.HEARTS, CardValue.ACE));
        h5.addCard(new BJCard(CardColor.CLUBS, CardValue.ACE));
        h5.addCard(new BJCard(CardColor.SPADES, CardValue.EIGHT));
        assertEquals(20, h5.getValue());

        // Testfall 6: 13
        Hand h6 = new Hand();
        h6.addCard(new BJCard(CardColor.SPADES, CardValue.ACE));
        h6.addCard(new BJCard(CardColor.CLUBS, CardValue.ACE));
        h6.addCard(new BJCard(CardColor.HEARTS, CardValue.ACE));
        assertEquals(13, h6.getValue());

        // Testfall 7: 13
        Hand h7 = new Hand();
        h7.addCard(new BJCard(CardColor.HEARTS, CardValue.TWO));
        h7.addCard(new BJCard(CardColor.SPADES, CardValue.QUEEN));
        h7.addCard(new BJCard(CardColor.CLUBS, CardValue.ACE));
        assertEquals(13, h7.getValue());

        // Testfall 8: 15
        Hand h8 = new Hand();
        h8.addCard(new BJCard(CardColor.HEARTS, CardValue.KING));
        h8.addCard(new BJCard(CardColor.SPADES, CardValue.FIVE));
        assertEquals(15, h8.getValue());

        // Testfall 9: 20
        Hand h9 = new Hand();
        h9.addCard(new BJCard(CardColor.HEARTS, CardValue.KING));
        h9.addCard(new BJCard(CardColor.SPADES, CardValue.JACK));
        assertEquals(20, h9.getValue());

        // Testfall 10: 15
        Hand h10 = new Hand();
        h10.addCard(new BJCard(CardColor.HEARTS, CardValue.FOUR));
        h10.addCard(new BJCard(CardColor.SPADES, CardValue.TWO));
        h10.addCard(new BJCard(CardColor.CLUBS, CardValue.SIX));
        h10.addCard(new BJCard(CardColor.DIAMONDS, CardValue.THREE));
        assertEquals(15, h10.getValue());

        // Testfall 11: 0
        Hand h11 = new Hand();
        assertEquals(0, h11.getValue());
    }
}
