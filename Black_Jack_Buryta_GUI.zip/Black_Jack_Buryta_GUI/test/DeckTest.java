import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

public class DeckTest {

    @Test
    public void testDeckInitialSizeIs52() {
        Stack stack = new Stack();
        Deck deck = new Deck(stack);

        assertEquals(52, deck.size(), "Ein neues Deck (aus Stack) muss 52 Karten enthalten.");
        assertFalse(deck.isEmpty(), "Ein neues Deck darf nicht leer sein.");
    }

    @Test
    public void testDrawReducesSizeAndReturnsCard() {
        Stack stack = new Stack();
        Deck deck = new Deck(stack);

        int before = deck.size();
        BJCard c = deck.drawCard();

        assertNotNull(c, "drawCard() darf bei nicht-leerem Deck nicht null zurückgeben.");
        assertEquals(before - 1, deck.size(), "Nach drawCard() muss die Deck-Größe um 1 kleiner sein.");
    }

    @Test
    public void testDrawAllThenEmpty() {
        Stack stack = new Stack();
        Deck deck = new Deck(stack);

        // 52 Karten ziehen
        for (int i = 0; i < 52; i++) {
            assertNotNull(deck.drawCard(), "Karte " + (i+1) + " sollte nicht null sein.");
        }

        assertTrue(deck.isEmpty(), "Deck sollte nach 52 Zügen leer sein.");
        assertNull(deck.drawCard(), "drawCard() muss null zurückgeben, wenn das Deck leer ist.");
        assertEquals(0, deck.size(), "Größe des leeren Decks muss 0 sein.");
    }

    @Test
    public void testGetCardsReturnsCopyNotBackingList() {
        Stack stack = new Stack();
        Deck deck = new Deck(stack);

        List<BJCard> cards = deck.getCards();
        int originalSize = deck.size();

        if (!cards.isEmpty()) {
            cards.remove(0);
        }


        assertEquals(originalSize, deck.size(), "getCards() muss eine Kopie der internen Liste liefern (keine Seiteneffekte).");
    }

    @Test
    public void testMultipleDecksFromStackDoNotBreakDeckBehaviour() {

        Stack stack = new Stack();
        int stackBefore = stack.size();
        Deck deck = new Deck(stack);

        assertTrue(stack.size() <= stackBefore - 52, "Stack sollte nach Konstruktion des Decks mindestens 52 Karten weniger haben.");


        assertEquals(52, deck.size(), "Deck sollte 52 Karten enthalten.");
        assertNotNull(deck.drawCard());
    }
}
