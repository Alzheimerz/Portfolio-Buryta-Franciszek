#include "rfid.h"

MFRC522 mfrc522(RFID_SS_PIN, RFID_RST_PIN);

void rfidInit() {
  Serial.println("Starte RC522...");

  SPI.begin(RFID_SCK_PIN, RFID_MISO_PIN, RFID_MOSI_PIN, RFID_SS_PIN);

  mfrc522.PCD_Init();   // Initialisierung auf dem aktiven SPI-Bus
  delay(100);
  Serial.println("RC522 initialisiert. Warte auf Karte...");
}

bool rfidCheck(String &uid) {
  if (!mfrc522.PICC_IsNewCardPresent() || !mfrc522.PICC_ReadCardSerial()) {
    return false;
  }

  uid = "";
  for (byte i = 0; i < mfrc522.uid.size; i++) {
    if (mfrc522.uid.uidByte[i] < 0x10) uid += "0";
    uid += String(mfrc522.uid.uidByte[i], HEX);
  }
  uid.toUpperCase();

  mfrc522.PICC_HaltA();
  mfrc522.PCD_StopCrypto1();
  Serial.println("Karte erkannt: " + uid);
  return true;
}
