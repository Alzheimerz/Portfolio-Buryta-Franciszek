#pragma once
#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>
#include <SPI.h>

#define TFT_CS   9
#define TFT_DC   10
#define TFT_RST  8
#define TFT_MOSI 12
#define TFT_SCLK 13

extern Adafruit_ST7735 tft;
extern int upgradeSelection;

extern unsigned long messageTimer;
extern bool messageActive;
extern const unsigned long MESSAGE_DURATION;


void displayInit();
void displayShowWelcome();
void displayShowSlots(const char* symbols[], int slot[]);
void displayShowSlotsBitmap(int slots[]);
void displayShowMessage(const String &msg);
void displayShowIntro();
void displayShowBet(int bet);
void displayShowUpgradeMenu(int selection);
int  displayUpgradeGetSelection();
void  displayUpgradeCount();
