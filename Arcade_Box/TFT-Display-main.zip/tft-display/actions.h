#pragma once
#include <Arduino.h>
#include "display.h"

void actionInit();                // Initialisiert Geldsystem
void actionLoadPlayer(const String &uid);  // Lädt playerMoney aus Preferences
void actionSavePlayer(const String &uid, int money); // Speichert für UID
void actionSetMoney(int amount);  // Setzt das Geld (im RAM)
void actionAddMoney(int amount);  // Addiert Geld (z.B. Gewinn)
void actionSubMoney(int amount);  // Subtrahiert Geld (z.B. Einsatz)
int  actionGetMoney();            // Gibt aktuellen Betrag zurück
void actionShowMoney();           // Zeigt Geld oben rechts auf Display
