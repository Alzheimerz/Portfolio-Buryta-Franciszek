#include "display.h"
#include "buzzer.h"
#include "rfid.h"
#include "actions.h"
#include "menu.h"
#include <WiFi.h>
#include <HTTPClient.h>

// --- PROTOTYPEN ---
void doSpin();
void runAdminMode();
int weightedRandom();
int symbolMultiplier(int sym);
int symbolFreeSpins(int sym);
bool attemptBuyUpgrade(int sel);
// Externe Funktion aus actions.cpp
extern void sendTransactionToServer(String uid, int currentMoney);

// --- PINS ---
#define BUTTON_SPIN 11     
#define JOY_X_PIN   19   
#define JOY_Y_PIN   20   
#define JOY_BTN_PIN 0  

// --- ADMIN UID ---
const String ADMIN_UID = "967599AC";

// --- SLOT SYSTEM ---
const int numSymbols = 6;
int slot[3] = {0, 0, 0};
bool playerLoggedIn = false;
bool guestMode = false;
bool gameStarted = false;
String currentUID = "";

// --- TIMER & DISPLAY MERKER ---
unsigned long messageTimer = 0;
bool messageActive = false;
const unsigned long MESSAGE_DURATION = 2000;
extern int lastMoney; 
extern int lastBet;

// --- BET SYSTEM ---
int betOptions[] = {5, 10, 20, 50};
int betIndex = 1;

// --- UPGRADE SYSTEM ---
bool inUpgradeMenu = false;
unsigned long menuButtonDownTime = 0;
const unsigned long LONGPRESS_MS = 1200;
int upgradePrices[] = {200, 150, 120};
int upgradeSelection = 0;

// --- FREE SPINS & WEIGHTS ---
int freeSpins = 0;
int symbolWeights[6] = {10, 10, 10, 10, 10, 10};

void setup() {
  Serial.begin(115200);
  delay(1000); 

  // 1. ZUERST HARDWARE & INTRO (Damit alles flüssig startet)
  displayInit();
  buzzerInit();
  
  // Das langsame Logo-Intro
  displayShowIntro(); 
  delay(500);

  rfidInit();
  actionInit();

  // Pins konfigurieren
  pinMode(BUTTON_SPIN, INPUT_PULLUP);
  pinMode(JOY_BTN_PIN, INPUT_PULLUP);
  pinMode(JOY_X_PIN, INPUT_PULLUP); 
  pinMode(JOY_Y_PIN, INPUT_PULLUP);

  // 2. JETZT WIFI STARTEN
  displayShowMessage("WiFi connecting...");
  WiFi.setTxPower(WIFI_POWER_11dBm);
  WiFi.begin("Normales WLAN", "Lorenz1807"); 

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 15) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    displayShowMessage("WiFi Online!");
  } else {
    displayShowMessage("WiFi Offline");
  }

  delay(1200);
  displayShowMessage("Scan Card!");
}

void loop() {
  // ---------------------------------------------------------
  //  RFID / LOGIN CHECK
  // ---------------------------------------------------------
  String uid;
  if (!playerLoggedIn) {
    if (rfidCheck(uid)) {
      currentUID = uid;
      buzzerPing();

      if (uid == ADMIN_UID) {
        runAdminMode();
        playerLoggedIn = true; 
        tft.fillScreen(ST77XX_BLACK);
        return;
      }

      actionLoadPlayer(uid);
      playerLoggedIn = true;
      displayShowMessage("Welcome!");
      delay(800);
      return;
    }
    return;
  }

  // ---------------------------------------------------------
  //  NACHRICHTEN-TIMER (LÖSCHEN NACH 2 SEK)
  // ---------------------------------------------------------
  if (messageActive && (millis() - messageTimer >= MESSAGE_DURATION)) {
    messageActive = false;
    tft.fillRect(0, 115, 160, 13, ST77XX_BLACK);
    if (playerLoggedIn) {
      lastMoney = -1; lastBet = -1; 
      actionShowMoney();
      displayShowBet(betOptions[betIndex]);
    } else {
      tft.setCursor(5, 117);
      tft.setTextColor(ST77XX_WHITE);
      tft.print("Scan Card!");
    }
  }

  // UI dauerhaft aktualisieren (ohne Flackern)
  actionShowMoney();
  displayShowBet(betOptions[betIndex]);

  // ---------------------------------------------------------
  //  SPIN BUTTON (PIN 11) - VERBESSERT GEGEN DAUER-SPIN
  // ---------------------------------------------------------
  if (digitalRead(BUTTON_SPIN) == LOW && !inUpgradeMenu) {
    delay(50); // Entprellen
    if (digitalRead(BUTTON_SPIN) == LOW) {
      if (!gameStarted) { 
        tft.fillScreen(ST77XX_BLACK); 
        gameStarted = true; 
      }

      int bet = betOptions[betIndex];
      if (freeSpins > 0) {
        freeSpins--;
        displayShowMessage("Free Spin!");
        doSpin();
      } else if (actionGetMoney() >= bet) {
        actionSubMoney(bet);
        doSpin();
      } else {
        displayShowMessage("No Money!");
        buzzerFail();
      }
      
      // SICHERHEIT: Warten bis Button losgelassen wird
      while(digitalRead(BUTTON_SPIN) == LOW) { delay(10); }
      delay(200); // Zusätzliche Pause
    }
  }

  // ---------------------------------------------------------
  //  JOYSTICK KLICK (MENÜ & NAVIGATION)
  // ---------------------------------------------------------
  if (digitalRead(JOY_BTN_PIN) == LOW && menuButtonDownTime == 0) {
    menuButtonDownTime = millis();
    delay(50); 
  } 
  else if (digitalRead(JOY_BTN_PIN) == HIGH && menuButtonDownTime != 0) {
    unsigned long pressLen = millis() - menuButtonDownTime;
    menuButtonDownTime = 0;

    if (pressLen >= LONGPRESS_MS) {
      // UPGRADE MENÜ TOGGLE
      inUpgradeMenu = !inUpgradeMenu;
      if (inUpgradeMenu) {
        displayShowUpgradeMenu(0); 
      } else {
        tft.fillScreen(ST77XX_BLACK);
      }
    } else {
      if (inUpgradeMenu) {
        // Upgrade Auswahl weiter
        upgradeSelection = (upgradeSelection + 1) % 3;
        displayShowUpgradeMenu(upgradeSelection);
      } else {
        // HAUPTMENÜ ÖFFNEN (menu.cpp)
        openMenu(playerLoggedIn, guestMode);
        tft.fillScreen(ST77XX_BLACK);
        lastMoney = -1; lastBet = -1;
      }
    }
  }

  // ---------------------------------------------------------
  //  JOYSTICK EINSATZ (BET) - HOCH/RUNTER ZYKLISCH
  // ---------------------------------------------------------
  if (!inUpgradeMenu && playerLoggedIn) {
    int yVal = digitalRead(JOY_Y_PIN); 
    int xVal = digitalRead(JOY_X_PIN);
    static bool joyReleased = true;

    if (yVal == LOW || xVal == LOW) { 
      if (joyReleased) {
        betIndex = (betIndex + 1) % 4; 
        displayShowBet(betOptions[betIndex]);
        buzzerPing();
        joyReleased = false;
      }
    } else {
      joyReleased = true; 
    }
  }
}

// ---------------------------------------------------------
//  SLOT LOGIK & ANIMATION
// ---------------------------------------------------------
void doSpin() {
  displayShowMessage("Spinning...");
  buzzerSlotSpin();

  // Animation: 2 schnelle Durchläufe
  for (int i = 0; i < 2; i++) {
    for (int r = 0; r < 3; r++) {
       slot[r] = random(0, numSymbols);
    }
    displayShowSlotsBitmap(slot);
    delay(150);
  }

  // Endergebnis berechnen
  for (int r = 0; r < 3; r++) slot[r] = weightedRandom();
  displayShowSlotsBitmap(slot);

  // Gewinnprüfung
  if (slot[0] == slot[1] && slot[1] == slot[2]) {
    int reward = betOptions[betIndex] * symbolMultiplier(slot[0]);
    actionAddMoney(reward);
    
    int bonusFS = symbolFreeSpins(slot[0]);
    freeSpins += bonusFS;
    
    if (bonusFS > 0) displayShowMessage("JACKPOT! +" + String(bonusFS) + "FS");
    else displayShowMessage("WIN! +" + String(reward));
    
    buzzerWin();
  } else {
    displayShowMessage("Try Again!");
    buzzerFail();
  }
}

int weightedRandom() {
  int total = 0; 
  for (int i = 0; i < numSymbols; i++) total += symbolWeights[i];
  int r = random(total), sum = 0;
  for (int i = 0; i < numSymbols; i++) { 
    sum += symbolWeights[i]; 
    if (r < sum) return i; 
  }
  return numSymbols - 1;
}

int symbolMultiplier(int sym) {
  switch(sym) { 
    case 0: return 2; case 1: return 4; case 2: return 6; 
    case 3: return 3; case 4: return 3; case 5: return 5; 
    default: return 2; 
  }
}

int symbolFreeSpins(int sym) { 
  return (sym == 2) ? 2 : 0; 
}

// ---------------------------------------------------------
//  UPGRADE KAUFEN
// ---------------------------------------------------------
bool attemptBuyUpgrade(int sel) {
  int price = upgradePrices[sel]; 
  if (actionGetMoney() < price) return false;
  
  actionSubMoney(price);
  if (sel == 0) symbolWeights[2] += 5; // Mehr Diamanten
  if (sel == 1) symbolWeights[1] += 5; // Mehr Sterne
  if (sel == 2) freeSpins += 1;
  return true;
}

// ---------------------------------------------------------
//  ADMIN MODUS
// ---------------------------------------------------------
void runAdminMode() {
  int adminSelection = 0;
  int lastAdminSelection = -1;
  const int adminItemCount = 3;
  const char* adminOptions[] = {"Refill Credits", "Change Payout", "Exit Admin"};
  unsigned long lastMove = 0;
  
  tft.fillScreen(ST77XX_BLACK);

  while (true) {
    int downState = digitalRead(JOY_Y_PIN);
    int btnState = digitalRead(JOY_BTN_PIN);

    if (downState == LOW && (millis() - lastMove > 300)) {
      adminSelection = (adminSelection + 1) % adminItemCount;
      lastMove = millis();
      buzzerPing();
    }

    if (adminSelection != lastAdminSelection) {
      tft.fillRect(0, 0, 160, 110, ST77XX_BLACK);
      tft.setTextColor(ST77XX_RED);
      tft.setCursor(10, 10); tft.println("=== ADMIN MODE ===");
      for (int i = 0; i < adminItemCount; i++) {
        tft.setCursor(10, 40 + i * 15);
        tft.setTextColor(i == adminSelection ? ST77XX_YELLOW : ST77XX_WHITE);
        tft.print(i == adminSelection ? "> " : "  ");
        tft.println(adminOptions[i]);
      }
      lastAdminSelection = adminSelection;
    }

    if (btnState == LOW) {
      buzzerPing(); 
      delay(400);

      if (adminSelection == 0) { // Refill
        displayShowMessage("Scan Card...");
        String tUID = ""; delay(1000);
        while (true) {
          if (rfidCheck(tUID)) {
            actionSavePlayer(tUID, 1000);
            if (tUID == currentUID) actionSetMoney(1000);
            displayShowMessage("Success: 1000$"); buzzerWin(); break;
          }
          if (digitalRead(JOY_BTN_PIN) == LOW) break;
          delay(50);
        }
        lastAdminSelection = -1;
      }
      else if (adminSelection == 1) { // Payout Submenu
        int pSel = 0; int lPSel = -1;
        const char* pOpts[] = {"Easy", "Normal", "Hard", "Back"};
        tft.fillScreen(ST77XX_BLACK);
        while (true) {
          if (digitalRead(JOY_Y_PIN) == LOW && (millis() - lastMove > 300)) {
            pSel = (pSel + 1) % 4; lastMove = millis(); buzzerPing();
          }
          if (pSel != lPSel) {
            tft.fillRect(0, 0, 160, 110, ST77XX_BLACK);
            tft.setCursor(10, 10); tft.setTextColor(ST77XX_MAGENTA); tft.println("SET PAYOUT:");
            for (int j = 0; j < 4; j++) {
              tft.setCursor(15, 40 + j * 15);
              tft.setTextColor(j == pSel ? ST77XX_YELLOW : ST77XX_WHITE);
              tft.print(j == pSel ? "> " : "  "); tft.println(pOpts[j]);
            }
            lPSel = pSel;
          }
          if (digitalRead(JOY_BTN_PIN) == LOW) {
            if (pSel == 0) { for(int i=0; i<6; i++) symbolWeights[i] = 20; }
            else if (pSel == 1) { for(int i=0; i<6; i++) symbolWeights[i] = 10; }
            else if (pSel == 2) { for(int i=0; i<6; i++) symbolWeights[i] = 5; symbolWeights[0] = 15; }
            break;
          }
          delay(20);
        }
        lastAdminSelection = -1;
      }
      else if (adminSelection == 2) { 
        playerLoggedIn = true; 
        gameStarted = false; 
        tft.fillScreen(ST77XX_BLACK); 
        return; 
      }
    }
    delay(20);
  }
}
