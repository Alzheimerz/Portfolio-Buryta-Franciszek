#include "display.h"
#include "symbols.h"

Adafruit_ST7735 tft = Adafruit_ST7735(TFT_CS, TFT_DC, TFT_MOSI, TFT_SCLK, TFT_RST);


void displayInit() {
  tft.initR(INITR_BLACKTAB);
  tft.setRotation(1);
  tft.fillScreen(ST77XX_BLACK);
}

void displayShowIntro() {
  tft.fillScreen(ST77XX_BLACK);
  // schneller slide-in
  for (int x = -80; x <= 20; x += 16) {   // größere Schritte
    tft.fillScreen(ST77XX_BLACK);
    tft.setTextSize(2);
    tft.setTextColor(ST77XX_RED);
    tft.setCursor(x, 10);
    tft.print("SLOT");
    tft.setCursor(x, 40);
    tft.setTextColor(ST77XX_YELLOW);
    tft.print("MACHINE");
    delay(30);   // kürzeres Delay
  }
  // Rahmen
  tft.drawRect(0,0,160,128,ST77XX_WHITE);
}


// Welcome (static)
void displayShowWelcome() {
  tft.fillScreen(ST77XX_BLACK);
  tft.setTextColor(ST77XX_GREEN);
  tft.setTextSize(2);
  tft.setCursor(20, 30);   // vorher 40
  tft.print("SLOT");
  tft.setCursor(20, 60);   // vorher 70
  tft.print("MACHINE");
}


// draws bitmaps in slots
void displayShowSlotsBitmap(int slots[]) {
  tft.fillRect(0, 20, 160, 90, ST77XX_BLACK); // area for reels
  int xPos[] = {10, 60, 110};
  for (int i = 0; i < 3; i++) {
    // draw framed icon with outline
    int x = xPos[i];
    int y = 30;
    // frame
    tft.fillRect(x-4, y-4, symbolWidth+8, symbolHeight+8, ST77XX_BLACK);
    tft.drawRect(x-5, y-5, symbolWidth+10, symbolHeight+10, ST77XX_WHITE);
    // draw bitmap
    tft.drawRGBBitmap(x, y, symbolBitmaps[slots[i]], symbolWidth, symbolHeight);
  }
}

// old text based slots kept for compatibility
void displayShowSlots(const char* symbols[], int slot[]) {
  tft.fillScreen(ST77XX_BLACK);
  tft.setTextColor(ST77XX_YELLOW);
  tft.setTextSize(3);
  int xPos[] = {20, 60, 100};
  for (int i = 0; i < 3; i++) {
    tft.setCursor(xPos[i], 50);
    tft.print(symbols[slot[i]]);
  }
}

void displayShowMessage(const String &msg) {
  tft.fillRect(0, 115, 160, 13, ST77XX_BLACK); 
  tft.setCursor(5, 117);
  tft.setTextColor(ST77XX_WHITE);
  tft.setTextSize(1);
  tft.print(msg);

  messageTimer = millis();
  messageActive = true;
}



int lastBet = -1; // Merker für den alten Einsatz

void displayShowBet(int bet) {
  if (bet == lastBet) {
    return;
  }

  // Bereich unten rechts löschen
  tft.fillRect(100, 115, 60, 13, ST77XX_BLACK); 
  tft.setTextColor(ST77XX_YELLOW);
  tft.setTextSize(1);
  
  tft.setCursor(105, 117);
  tft.print("Bet:");
  tft.print(bet);

  lastBet = bet;
}




void displayUpgradeCount() {
    tft.fillScreen(ST77XX_BLACK);
    tft.setCursor(10, 10);
    tft.setTextColor(ST77XX_WHITE);
    tft.print("Upgrades:");
}

int displayUpgradeGetSelection() {
    return upgradeSelection;
}

void displayShowUpgradeMenu(int selection) {
    tft.fillScreen(ST77XX_BLACK);
    tft.setCursor(5, 10);
    tft.setTextSize(1);
    tft.setTextColor(ST77XX_YELLOW);
    tft.print("Choose Upgrade:");

    tft.setCursor(20, 40);
    tft.setTextColor(selection == 0 ? ST77XX_GREEN : ST77XX_WHITE);
    tft.print("1) Higher Chance");

    tft.setCursor(20, 60);
    tft.setTextColor(selection == 1 ? ST77XX_GREEN : ST77XX_WHITE);
    tft.print("2) Bonus Spins");

    tft.setCursor(20, 80);
    tft.setTextColor(selection == 2 ? ST77XX_GREEN : ST77XX_WHITE);
    tft.print("3) Higher Multiplier");
}
