#include "menu.h"
#include "display.h"
#include "buzzer.h"

// Zugriff auf globale Variablen der main.ino
extern bool inUpgradeMenu;
extern int upgradeSelection;
extern String currentUID; 

// Prototypen der Funktionen aus actions.cpp
extern void sendTransactionToServer(String uid, int currentMoney);
extern int actionGetMoney();

// Menü-Texte (Englisch) - Jetzt mit "Save Game"
const char* menuItemsLoggedIn[] = {
    "Logout",
    "Upgrades",
    "Get Web-Token",
    "Save Game",
    "Back"
};

const char* menuItemsGuest[] = {
    "Leave Guest",
    "Back"
};

#define JOY_DOWN_PIN 20  
#define JOY_BTN_PIN  0   

int getJoystickSelection(int itemCount, bool playerLoggedIn) {
    int selection = 0;
    int lastSelection = -1; 
    unsigned long lastMove = 0;

    tft.fillScreen(ST77XX_BLACK); 

    while (true) {
        int downState = digitalRead(JOY_DOWN_PIN);
        int btnState = digitalRead(JOY_BTN_PIN);

        // Zyklische Navigation nach unten
        if (downState == LOW && (millis() - lastMove > 250)) {
            selection = (selection + 1) % itemCount; 
            lastMove = millis();
            buzzerPing();
        }

        // Flackerfreie Anzeige
        if (selection != lastSelection) {
            tft.fillRect(0, 0, 160, 128, ST77XX_BLACK); 
            tft.setTextSize(1);
            tft.setCursor(15, 15);
            tft.setTextColor(ST77XX_WHITE);
            tft.println("--- MENU ---");

            for (int i = 0; i < itemCount; i++) {
                tft.setCursor(15, 35 + i * 16);
                if (i == selection) {
                    tft.setTextColor(ST77XX_YELLOW);
                    tft.print("> ");
                } else {
                    tft.setTextColor(ST77XX_WHITE);
                    tft.print("  ");
                }
                tft.print(playerLoggedIn ? menuItemsLoggedIn[i] : menuItemsGuest[i]);
            }
            lastSelection = selection; 
        }

        if (btnState == LOW) {
            buzzerPing();
            delay(300); 
            return selection;
        }
        delay(20); 
    }
}

void openMenu(bool &playerLoggedIn, bool &guestMode) {
    // itemCount ist 5 für eingeloggte Spieler, 2 für Gäste
    int itemCount = playerLoggedIn ? 5 : 2;
    int selection = getJoystickSelection(itemCount, playerLoggedIn);

    if (playerLoggedIn) {
        if (selection == 0) { // Logout
            displayShowMessage("Logging out...");
            playerLoggedIn = false;
            guestMode = false;
            delay(800);
            tft.fillScreen(ST77XX_BLACK);
            displayShowMessage("Scan Card!");
        }
        else if (selection == 1) { // Upgrades
            inUpgradeMenu = true;
            upgradeSelection = 0;
            displayShowUpgradeMenu(upgradeSelection);
        }
        else if (selection == 2) { // GET WEB-TOKEN PAGE
            // Hier kein automatischer Post mehr!
            bool inTokenPage = true;
            tft.fillScreen(ST77XX_BLACK);
            
            while (inTokenPage) {
                tft.setCursor(10, 15);
                tft.setTextSize(1);
                tft.setTextColor(ST77XX_CYAN);
                tft.println("--- YOUR WEB ID ---");

                tft.setTextSize(2);
                tft.setTextColor(ST77XX_WHITE);
                tft.setCursor(20, 55); 
                tft.println(currentUID);

                tft.setTextSize(1);
                tft.setCursor(15, 105);
                tft.setTextColor(ST77XX_YELLOW);
                tft.println("> Back to Menu");

                if (digitalRead(JOY_BTN_PIN) == LOW) {
                    buzzerPing();
                    delay(300); 
                    inTokenPage = false; 
                }
                delay(50); 
            }
            tft.fillScreen(ST77XX_BLACK);
        }
        else if (selection == 3) { // SAVE GAME (POST Request)
            tft.fillScreen(ST77XX_BLACK);
            tft.setCursor(10, 50);
            tft.setTextColor(ST77XX_CYAN);
            tft.println("Saving to Cloud...");
            
            // Sendet die Daten an den NodeJS Server
            sendTransactionToServer(currentUID, actionGetMoney());
            
            delay(1500);
            tft.setCursor(10, 70);
            tft.setTextColor(ST77XX_GREEN);
            tft.println("Game Saved!");
            buzzerWin();
            delay(1000);
            tft.fillScreen(ST77XX_BLACK);
        }
        // Selection 4 (Back) schliesst das Menü automatisch
    } 
    else { // Guest Mode
        if (selection == 0) { // Leave Guest
            displayShowMessage("Guest finished");
            playerLoggedIn = false;
            guestMode = false;
            delay(800);
            tft.fillScreen(ST77XX_BLACK);
            displayShowMessage("Scan Card!");
        }
    }
}
