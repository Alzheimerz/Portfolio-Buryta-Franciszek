#include "actions.h"
#include <WiFi.h>
#include <HTTPClient.h>

static int playerMoney = 0;
static String currentUID_global = "";
int lastMoney = -1; 

const char* serverBaseUrl = "http://10.22.55.195:3000/api/users";

void actionInit() {
  
}

void sendTransactionToServer(String uid, int currentMoney) {
  if (WiFi.status() != WL_CONNECTED || uid == "") return; 

  HTTPClient http;
  http.setTimeout(1500); 
  
  http.begin("http://10.22.55.195:3000/api/users/transaction");
  http.addHeader("Content-Type", "application/json");

  String json = "{\"rfid\": \"" + uid + "\", \"name\": \"Spieler\", \"money\": " + String(currentMoney) + ".00}";
  
  Serial.print("Sending POST to Server: ");
  Serial.println(json);

  int httpResponseCode = http.POST(json);
  
  if (httpResponseCode > 0) {
    Serial.printf("Server Response Code: %d\n", httpResponseCode);
  } else {
    Serial.printf("Error Code: %s\n", http.errorToString(httpResponseCode).c_str());
  }
  
  http.end();
}

void actionLoadPlayer(const String &uid) {
  currentUID_global = uid;
  
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    String url = String(serverBaseUrl) + "/" + uid;
    http.begin(url);
    
    int httpResponseCode = http.GET();
    
    if (httpResponseCode == 200) {
      String payload = http.getString();
      
      int startPos = payload.indexOf("\"money\":");
      if (startPos != -1) {
        startPos += 8;
        int endPos = payload.indexOf(",", startPos);
        if (endPos == -1) endPos = payload.indexOf("}", startPos);
        
        String moneyVal = payload.substring(startPos, endPos);
        moneyVal.replace("\"", "");   // Anführungszeichen entfernen
        playerMoney = moneyVal.toFloat();
        Serial.print("Data loaded! Money: ");
        Serial.println(playerMoney);
      }
    } else {
      Serial.printf("GET failed (%d), using default 100\n", httpResponseCode);
      playerMoney = 100;
    }
    http.end();
  } else {
    playerMoney = 100;
  }
  
  actionShowMoney();
}

void actionSavePlayer(const String &uid, int money) {
  if (uid == currentUID_global) playerMoney = money;
  actionShowMoney();
  sendTransactionToServer(uid, money);
}

void actionSetMoney(int amount) {
  playerMoney = amount;
  if (currentUID_global.length() > 0) {
    sendTransactionToServer(currentUID_global, playerMoney);
  }
  actionShowMoney();
}

void actionAddMoney(int amount) {
  playerMoney += amount;
  if (currentUID_global.length() > 0) {
    sendTransactionToServer(currentUID_global, playerMoney);
  }
  actionShowMoney();
}

void actionSubMoney(int amount) {
  playerMoney -= amount;
  if (playerMoney < 0) playerMoney = 0;
  
  if (currentUID_global.length() > 0) {
    sendTransactionToServer(currentUID_global, playerMoney);
  }
  actionShowMoney();
}

int actionGetMoney() {
  return playerMoney;
}

void actionShowMoney() {
  if (playerMoney == lastMoney) return; 

  tft.fillRect(0, 115, 100, 13, ST77XX_BLACK); 
  tft.setTextColor(ST77XX_CYAN);
  tft.setTextSize(1);
  
  tft.setCursor(5, 117);
  tft.print("Credits: $");
  tft.print(playerMoney);

  lastMoney = playerMoney;
}
