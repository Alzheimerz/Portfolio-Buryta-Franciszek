#pragma once
#include <Arduino.h>

void openMenu(bool &playerLoggedIn, bool &guestMode);