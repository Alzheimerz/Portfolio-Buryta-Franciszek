#include "symbols.h"
#include "cherry.h"
#include "star.h"
#include "diamond.h"
#include "seven.h"
#include "lemon.h"
#include "bell.h"

const uint16_t* symbolBitmaps[] = {
  cherry_icon,
  star_icon,
  diamond_icon,
  seven_icon,
  lemon_icon,
  bell_icon
};

const int symbolWidth = 20;
const int symbolHeight = 20;