#pragma once
#include <Arduino.h>

extern const uint16_t* symbolBitmaps[];
extern const int symbolWidth;
extern const int symbolHeight;