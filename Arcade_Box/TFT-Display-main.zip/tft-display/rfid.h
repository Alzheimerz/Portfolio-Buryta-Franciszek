#pragma once
#include <Arduino.h>
#include <SPI.h>
#include <MFRC522.h>

#define RFID_SS_PIN   3   // SDA 
#define RFID_RST_PIN  4   // RST/RES
#define RFID_SCK_PIN  5   // SCK
#define RFID_MISO_PIN 7   // MISO
#define RFID_MOSI_PIN 6   // MOSI

void rfidInit();
bool rfidCheck(String &uid);
