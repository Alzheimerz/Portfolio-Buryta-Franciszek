#pragma once
#include <Arduino.h>

// Pin und LEDC-Konfiguration
#define BUZZER_PIN 2
#define BUZZER_CHANNEL 0
#define BUZZER_FREQUENCY 1000  // Grundfrequenz
#define BUZZER_RESOLUTION 10

void buzzerInit();
void buzzerPing();
void buzzerWin();
void buzzerFail();
void buzzerSlotSpin();