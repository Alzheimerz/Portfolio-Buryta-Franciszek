#include "buzzer.h"
#include "driver/ledc.h"

void buzzerInit() {
  // LEDC-Timer konfigurieren
  ledc_timer_config_t ledc_timer = {
    .speed_mode       = LEDC_LOW_SPEED_MODE,
    .duty_resolution  = (ledc_timer_bit_t)BUZZER_RESOLUTION,
    .timer_num        = LEDC_TIMER_0,
    .freq_hz          = BUZZER_FREQUENCY,
    .clk_cfg          = LEDC_AUTO_CLK
  };
  ledc_timer_config(&ledc_timer);

  // LEDC-Kanal konfigurieren
  ledc_channel_config_t ledc_channel = {
    .gpio_num       = BUZZER_PIN,
    .speed_mode     = LEDC_LOW_SPEED_MODE,
    .channel        = (ledc_channel_t)BUZZER_CHANNEL,
    .intr_type      = LEDC_INTR_DISABLE,
    .timer_sel      = LEDC_TIMER_0,
    .duty           = 0,
    .hpoint         = 0
  };
  ledc_channel_config(&ledc_channel);
}

// interner Helfer: Ton mit Frequenz und Dauer
static void playTone(int freq, int duration) {
  ledc_set_freq(LEDC_LOW_SPEED_MODE, LEDC_TIMER_0, freq);
  ledc_set_duty(LEDC_LOW_SPEED_MODE, (ledc_channel_t)BUZZER_CHANNEL, 512); // 50 %
  ledc_update_duty(LEDC_LOW_SPEED_MODE, (ledc_channel_t)BUZZER_CHANNEL);
  delay(duration);
  ledc_set_duty(LEDC_LOW_SPEED_MODE, (ledc_channel_t)BUZZER_CHANNEL, 0);
  ledc_update_duty(LEDC_LOW_SPEED_MODE, (ledc_channel_t)BUZZER_CHANNEL);
}

void buzzerPing() {
  playTone(1200, 100);
}

void buzzerWin() {
  int melody[] = {523, 659, 784, 1047};
  for (int i = 0; i < 4; i++) {
    playTone(melody[i], 150);
  }
}

void buzzerSlotSpin() {
  int freqs[] = {600,700,800,900,1000};
  int delays[] = {90,75,60,45,30};
  for (int i=0;i<5;i++) {
    ledc_set_freq(LEDC_LOW_SPEED_MODE, LEDC_TIMER_0, freqs[i]);
    ledc_set_duty(LEDC_LOW_SPEED_MODE, (ledc_channel_t)BUZZER_CHANNEL, 512);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, (ledc_channel_t)BUZZER_CHANNEL);
    delay(delays[i]);
  }
  // final tick
  playTone(300, 100);
  ledc_set_duty(LEDC_LOW_SPEED_MODE, (ledc_channel_t)BUZZER_CHANNEL, 0);
  ledc_update_duty(LEDC_LOW_SPEED_MODE, (ledc_channel_t)BUZZER_CHANNEL);
}



void buzzerFail() {
  playTone(200, 300);
}
