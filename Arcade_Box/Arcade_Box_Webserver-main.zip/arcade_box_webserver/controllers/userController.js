const UserModel = require("../models/userModel");

class UserController {

    static async transaction(req, res) {
        try {
            const { rfid, name, money } = req.body;

            if (!rfid || !name || money === undefined) {
                return res.status(400).json({
                    error: "rfid, name und money erforderlich"
                });
            }

            const moneyValue = parseFloat(money);

            if (isNaN(moneyValue)) {
                return res.status(400).json({
                    error: "money muss Zahl sein"
                });
            }

            await UserModel.upsertAndUpdateMoney(rfid, name, moneyValue);

            // Wenn API-Request (z.B. ESP)
            if (req.is("application/json") || req.headers["content-type"]?.includes("application/json")) {
                return res.json({
                    status: "ok",
                    rfid,
                    moneyChange: moneyValue
                });
            }

            // Wenn Formular
            res.redirect(303, "/");

        } catch (error) {
            console.error(error);
            res.status(500).json({ error: "Serverfehler" });
        }
    }

    static async deleteUser(req, res) {
        try {
            // Erlaube rfid sowohl im Body (Form) als auch als Query-Parameter (falls genutzt)
            const rfid = req.body?.rfid || req.query?.rfid;

            // Bei Formular-Submits möchten wir auf die Hauptseite zurückkehren;
            // API-Clients hingegen sollen klare JSON-Fehler erhalten.
            if (!rfid) {
                if (req.is("application/json") || req.headers["content-type"]?.includes("application/json")) {
                    return res.status(400).json({ error: "rfid erforderlich" });
                }
                return res.redirect(303, "/");
            }

            await UserModel.deleteByRFID(rfid);

            // Wenn API-Request (z.B. JSON) -> JSON-Antwort
            if (req.is("application/json") || req.headers["content-type"]?.includes("application/json")) {
                return res.json({ status: "deleted", rfid });
            }

            // Wenn normales Formular-Submit -> zurück zur Startseite
            return res.redirect(303, "/");

        } catch (error) {
            console.error(error);
            // Für API-Requests JSON-Fehler
            if (req.is("application/json") || req.headers["content-type"]?.includes("application/json")) {
                return res.status(500).json({ error: "Serverfehler" });
            }
            // Für Formular-Submits: Redirect zurück (evtl. mit Fehleranzeige später)
            return res.redirect(303, "/");
        }
    }

    // Login zu einem Benutzer (mit Passwort)
    static async login(req, res) {
        try {
            const { identifier, password } = req.body;

            if (!identifier || !password) {
                return res.status(400).json({ error: "Benutzername/ID und Passwort erforderlich" });
            }

            // Authentifiziere Benutzer mit Passwort
            const user = await UserModel.authenticateUser(identifier, password);

            if (!user) {
                return res.status(401).json({ error: "Ungültige Anmeldedaten" });
            }

            req.session.currentUser = {
                id: user.id,
                name: user.name
            };
            req.session.isAdmin = user.is_admin || false;

            res.json({
                status: "logged_in",
                user: req.session.currentUser,
                isAdmin: req.session.isAdmin
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: "Serverfehler" });
        }
    }

    // Logout
    static async logout(req, res) {
        req.session.destroy((err) => {
            if (err) {
                return res.status(500).json({ error: "Logout fehlgeschlagen" });
            }
            res.json({ status: "logged_out" });
        });
    }

    // Admin: Benutzer löschen
    static async adminDeleteUser(req, res) {
        try {
            if (!req.session.isAdmin) {
                return res.status(403).json({ error: "Nur Admin darf diesen Benutzer löschen" });
            }

            const userId = req.params.userId || req.body.userId;

            if (!userId) {
                return res.status(400).json({ error: "userId erforderlich" });
            }

            await UserModel.deleteById(userId);
            res.json({ status: "deleted" });
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: "Serverfehler" });
        }
    }

    // Admin: Geld anpassen
    static async adminUpdateMoney(req, res) {
        try {
            if (!req.session.isAdmin) {
                return res.status(403).json({ error: "Nur Admin darf Geld anpassen" });
            }

            const userId = req.params.userId || req.body.userId;
            const { money } = req.body;

            if (!userId || money === undefined) {
                return res.status(400).json({ error: "userId und money erforderlich" });
            }

            const moneyValue = parseFloat(money);
            if (isNaN(moneyValue)) {
                return res.status(400).json({ error: "money muss Zahl sein" });
            }

            await UserModel.updateMoney(userId, moneyValue);
            res.json({ status: "updated" });
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: "Serverfehler" });
        }
    }

    // Admin: Namen ändern
    static async adminUpdateName(req, res) {
        try {
            if (!req.session.isAdmin) {
                return res.status(403).json({ error: "Nur Admin darf Namen ändern" });
            }

            const userId = req.params.userId || req.body.userId;
            const { name } = req.body;

            if (!userId || !name) {
                return res.status(400).json({ error: "userId und name erforderlich" });
            }

            await UserModel.updateName(userId, name);
            res.json({ status: "updated" });
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: "Serverfehler" });
        }
    }

    // Benutzer: Namen ändern (nur der eigene)
    static async updateOwnName(req, res) {
        try {
            if (!req.session.currentUser) {
                return res.status(403).json({ error: "Du musst angemeldet sein" });
            }

            const { name } = req.body;

            if (!name) {
                return res.status(400).json({ error: "name erforderlich" });
            }

            await UserModel.updateName(req.session.currentUser.id, name);
            req.session.currentUser.name = name;

            res.json({ status: "updated", user: req.session.currentUser });
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: "Serverfehler" });
        }
    }

    // Admin: Alle Benutzer mit Details abrufen
    static async getAdminUsers(req, res) {
        try {
            if (!req.session.isAdmin) {
                return res.status(403).json({ error: "Nur Admin darf diesen Bereich sehen" });
            }

            const users = await UserModel.getAll();
            const stats = await UserModel.getStatistics();

            res.json({ users, stats });
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: "Serverfehler" });
        }
    }

    // Registriere neuen User
    static async register(req, res) {
        try {
            const pool = require("../config/db");
            const { rfid, name, password, adminPassword } = req.body;

            if (!rfid || !name || !password) {
                return res.status(400).json({ error: "rfid, name und password erforderlich" });
            }

            if (password.length < 6) {
                return res.status(400).json({ error: "Passwort muss mindestens 6 Zeichen lang sein" });
            }

            // Überprüfe ob es bereits einen User mit dieser RFID oder diesem Namen gibt
            const [existingUsers] = await pool.execute(
                `SELECT id FROM users WHERE rfid = ? OR name = ?`,
                [rfid, name]
            );

            if (existingUsers && existingUsers.length > 0) {
                return res.status(400).json({ error: "RFID oder Benutzername existiert bereits" });
            }

            const isAdmin = adminPassword && adminPassword === process.env.ADMIN_PASSWORD;

            const userId = await UserModel.registerUser(rfid, name, password, isAdmin);

            req.session.currentUser = {
                id: userId,
                name: name
            };
            req.session.isAdmin = isAdmin;

            res.json({
                status: "registered",
                userId,
                isAdmin,
                user: req.session.currentUser
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: "Registrierung fehlgeschlagen" });
        }
    }
}

module.exports = UserController;