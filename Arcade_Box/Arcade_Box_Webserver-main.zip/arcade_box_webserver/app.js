require("dotenv").config();

const createError = require("http-errors");
const express = require("express");
const path = require("path");
const cookieParser = require("cookie-parser");
const logger = require("morgan");
const cors = require("cors");
const { engine } = require("express-handlebars");
const session = require("express-session");

const userRoutes = require("./routes/userRoutes");
const UserModel = require("./models/userModel");

const app = express();


// CORS muss vor Session kommen
app.use(cors({
  origin: "*",
  methods: ["GET", "POST"],
  allowedHeaders: ["Content-Type"]
}));

// Session-Middleware MUSS vor res.locals Middleware kommen
app.use(session({
  secret: process.env.SESSION_SECRET || 'arcade-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 24 * 60 * 60 * 1000, // 24 Stunden
    secure: false, // Setze auf true wenn HTTPS
    httpOnly: true
  }
}));

// make current year available to all views (used by layout footer)
app.use((req, res, next) => {
  res.locals.year = new Date().getFullYear();
  res.locals.currentUser = req.session.currentUser || null;
  res.locals.isAdmin = req.session.isAdmin || false;
  next();
});

app.engine("hbs", engine({
  extname: ".hbs",
  defaultLayout: "main",
  helpers: {
    eq: function(a, b, options) {
      if (options && options.fn) {
        return a === b ? options.fn(this) : options.inverse(this);
      }
      return a === b;
    },
    gt: (a, b) => a > b,
    isSelected: (value, current) => value === current ? 'selected' : '',
    json: (obj) => JSON.stringify(obj),
    formatDate: (date) => {
      if (!date) return '-';
      return new Date(date).toLocaleDateString('de-DE', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
      });
    },
    formatDateTime: (date) => {
      if (!date) return '-';
      return new Date(date).toLocaleDateString('de-DE', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      });
    }
  }
}));
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "hbs");

app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

app.get("/", async (req, res, next) => {
  try {
    const { search, sort } = req.query;
    let users;

    if (search) {
      users = await UserModel.searchUsers(search);
    } else {
      users = await UserModel.getAll();
    }

    // Sortierung
    if (sort === 'name') {
      users.sort((a, b) => a.name.localeCompare(b.name));
    } else if (sort === 'geld_asc') {
      users.sort((a, b) => a.geld - b.geld);
    } else if (sort === 'geld_desc') {
      users.sort((a, b) => b.geld - a.geld);
    }
    // Standard: nach Datum absteigend (bereits sortiert)

    // Hole Statistiken
    const stats = await UserModel.getStatistics();

    res.render("home", { users, search, sort, stats });
  } catch (err) {
    next(err);
  }
});

// Detailansicht für einen Benutzer
app.get("/user/:userId", async (req, res, next) => {
  try {
    const { userId } = req.params;
    const user = await UserModel.getById(userId);

    if (!user) {
      return next(new Error("Benutzer nicht gefunden"));
    }

    const transactions = await UserModel.getTransactionHistory(userId);
    res.render("user-detail", { user, transactions });
  } catch (err) {
    next(err);
  }
});

// Admin Panel
app.get("/admin", (req, res, next) => {
  if (!req.session.isAdmin) {
    return res.status(403).render("error", {
      message: "Zugriff verweigert",
      error: { status: 403 }
    });
  }
  res.render("admin");
});

// Login Seite
app.get("/login", (req, res) => {
  res.render("login");
});

app.use("/api/users", userRoutes);
app.get("/help", (req, res) => {
  res.render("help");
});

app.use(function(req, res, next) {
  next(createError(404));
});

app.use(function(err, req, res, next) {
  res.status(err.status || 500);

  // API Fehler als JSON zurückgeben
  if (req.originalUrl.startsWith("/api/")) {
    return res.json({
      error: err.message
    });
  }

  res.render("error", {
    message: err.message,
    error: req.app.get("env") === "development" ? err : {}
  });
});

module.exports = app;