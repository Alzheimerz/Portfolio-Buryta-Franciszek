const express = require("express");
const router = express.Router();
const UserController = require("../controllers/userController");
const UserModel = require("../models/userModel");

// GET: Alle Benutzer (für API)
router.get("/all", async (req, res, next) => {
  try {
    const users = await UserModel.getAll();
    res.json(users);
  } catch (error) {
    next(error);
  }
});

// GET: Statistiken
router.get("/statistics", async (req, res, next) => {
  try {
    const stats = await UserModel.getStatistics();
    res.json(stats);
  } catch (error) {
    next(error);
  }
});

// GET: Admin - Alle Benutzer und Statistiken
router.get("/admin/data", UserController.getAdminUsers);

// Benutzer-Transaktionen
router.post("/transaction", UserController.transaction);
router.post("/delete", UserController.deleteUser);

// Benutzergeld laden
router.get('/:rfid', async (req, res) => {
  try {

    const user = await UserModel.getByRFID(req.params.rfid);

    if (user) {
      res.json(user);
    } else {
      res.json({
        rfid: req.params.rfid,
        money: 100,
        name: "New Player"
      });
    }

  } catch (error) {
    console.error("LOAD USER ERROR:", error);
    res.status(500).json({ error: "DB Fehler" });
  }
});

// Authentifizierung
router.post("/login", UserController.login);
router.post("/logout", UserController.logout);
router.post("/register", UserController.register);

// Benutzer: Eigener Name
router.put("/profile/name", UserController.updateOwnName);

// Admin: Verwaltung
router.delete("/admin/users/:userId", UserController.adminDeleteUser);
router.put("/admin/users/:userId/money", UserController.adminUpdateMoney);
router.put("/admin/users/:userId/name", UserController.adminUpdateName);

module.exports = router;
