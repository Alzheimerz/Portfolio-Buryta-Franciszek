const pool = require("../config/db");
const bcrypt = require("bcrypt");

class UserModel {

    static async upsertAndUpdateMoney(rfid, name, amount) {
        const connection = await pool.getConnection();

        try {
            await connection.beginTransaction();

            const totalAmount = Number(amount);

            const [rows] = await connection.execute(
                "SELECT * FROM users WHERE rfid = ? FOR UPDATE",
                [rfid]
            );

            let userId;
            let balanceBefore = 0;
            let amountChange = totalAmount;

            if (rows.length === 0) {
                // Neuer User
                const [result] = await connection.execute(
                    `INSERT INTO users (rfid, name, geld, last_highscore_date)
                     VALUES (?, ?, ?, NOW())`,
                    [rfid, name, totalAmount]
                );

                userId = result.insertId;

            } else {
                // Bestehender User
                const user = rows[0];
                userId = user.id;

                balanceBefore = Number(user.geld);
                amountChange = totalAmount - balanceBefore;

                await connection.execute(
                    `UPDATE users
                     SET geld = ?, last_highscore_date = NOW()
                     WHERE rfid = ?`,
                    [totalAmount, rfid]
                );
            }

            // Transaktion speichern
            await connection.execute(
                `INSERT INTO transactions
                     (user_id, amount, balance_before, amount_change)
                 VALUES (?, ?, ?, ?)`,
                [userId, totalAmount, balanceBefore, amountChange]
            );

            await connection.commit();

            return {
                userId,
                balanceBefore,
                newBalance: totalAmount,
                amountChange
            };

        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    }

    // NEU: Direktes Update des Geldbetrags per ID
    static async updateMoney(id, newAmount) {
        const connection = await pool.getConnection();

        try {
            await connection.beginTransaction();

            const [rows] = await connection.execute(
                "SELECT geld FROM users WHERE id = ? FOR UPDATE",
                [id]
            );

            if (rows.length === 0) throw new Error("User nicht gefunden");

            const balanceBefore = Number(rows[0].geld);
            const amountChange = newAmount - balanceBefore;

            await connection.execute(
                "UPDATE users SET geld = ? WHERE id = ?",
                [newAmount, id]
            );

            await connection.execute(
                `INSERT INTO transactions (user_id, amount, balance_before, amount_change)
                 VALUES (?, ?, ?, ?)`,
                [id, newAmount, balanceBefore, amountChange]
            );

            await connection.commit();

            return { balanceBefore, newBalance: newAmount, amountChange };

        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    }

    static async getAll() {
        const [rows] = await pool.execute(
            `SELECT id, name, geld, last_highscore_date
             FROM users
             ORDER BY last_highscore_date DESC`
        );
        return rows;
    }

    static async getById(id) {
        const [rows] = await pool.execute(
            "SELECT * FROM users WHERE id = ?",
            [id]
        );
        return rows[0] || null;
    }

    static async getTransactionHistory(userId) {
        const [rows] = await pool.execute(
            `SELECT id, amount, balance_before, amount_change, created_at
             FROM transactions
             WHERE user_id = ?
             ORDER BY created_at DESC`,
            [userId]
        );
        return rows;
    }

    static async updateName(id, newName) {
        await pool.execute(
            "UPDATE users SET name = ? WHERE id = ?",
            [newName, id]
        );
    }

    static async deleteById(id) {
        await pool.execute("DELETE FROM users WHERE id = ?", [id]);
    }

    static async deleteByRFID(rfid) {
        await pool.execute("DELETE FROM users WHERE rfid = ?", [rfid]);
    }

    static async searchUsers(query) {
        const [rows] = await pool.execute(
            `SELECT id, name, geld, last_highscore_date
             FROM users
             WHERE name LIKE ? OR id LIKE ?
             ORDER BY last_highscore_date DESC`,
            [`%${query}%`, `%${query}%`]
        );
        return rows;
    }

    static async getStatistics() {
        try {
            const [transactions] = await pool.execute(
                `SELECT SUM(amount_change) as totalChange FROM transactions`
            );

            const [users] = await pool.execute(
                `SELECT COUNT(*) as totalUsers,
                        SUM(geld) as totalMoneyInCirculation
                 FROM users`
            );

            return {
                totalUsers: users[0]?.totalUsers || 0,
                totalMoneyInCirculation: users[0]?.totalMoneyInCirculation || 0,
                netChange: transactions[0]?.totalChange || 0
            };
        } catch (error) {
            console.error("Fehler in getStatistics:", error);
            return {
                totalUsers: 0,
                totalMoneyInCirculation: 0,
                netChange: 0
            };
        }
    }

    static async hashPassword(password) {
        const salt = await bcrypt.genSalt(10);
        return bcrypt.hash(password, salt);
    }

    static async comparePassword(password, hash) {
        return bcrypt.compare(password, hash);
    }

    static async registerUser(rfid, name, password, isAdmin = false) {
        const hashedPassword = await this.hashPassword(password);

        const [result] = await pool.execute(
            `INSERT INTO users
                 (rfid, name, password, is_admin, geld, last_highscore_date)
             VALUES (?, ?, ?, ?, 0, NOW())`,
            [rfid, name, hashedPassword, isAdmin ? 1 : 0]
        );

        return result.insertId;
    }

    static async authenticateUser(identifier, password) {
        const [rows] = await pool.execute(
            `SELECT * FROM users
             WHERE id = ? OR name = ? OR rfid = ?`,
            [identifier, identifier, identifier]
        );

        if (rows.length === 0) return null;

        const user = rows[0];
        const isPasswordValid = await this.comparePassword(password, user.password);

        if (!isPasswordValid) return null;

        return user;
    }
    static async getByRFID(rfid) {
        const [rows] = await pool.execute(
            "SELECT rfid, name, geld FROM users WHERE rfid = ?",
            [rfid]
        );

        if (rows.length === 0) return null;

        return {
            rfid: rows[0].rfid,
            name: rows[0].name,
            money: rows[0].geld
        };
    }
}


module.exports = UserModel;